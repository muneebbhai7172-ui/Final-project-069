/**
 * Admin App - Mock Data and Functions for Frontend-Only Mode
 * Provides dummy data for all admin pages without backend
 */

// ========== DUMMY DATA ==========

const ADMIN_MEDICINES = [
    { id: 1, name: 'Panadol Extra 500mg', generic: 'Paracetamol', category: 'Pain Relief', price: 85, cost: 60, stock: 150, shelf: 'A1', batch: 'BT2024001', expiry: '2025-12-01', manufacturer: 'GSK' },
    { id: 2, name: 'Augmentin 625mg', generic: 'Amoxicillin+Clavulanate', category: 'Antibiotics', price: 450, cost: 320, stock: 80, shelf: 'B2', batch: 'BT2024002', expiry: '2025-06-15', manufacturer: 'GSK' },
    { id: 3, name: 'Omeprazole 20mg', generic: 'Omeprazole', category: 'Digestive', price: 120, cost: 80, stock: 200, shelf: 'C3', batch: 'BT2024003', expiry: '2025-09-20', manufacturer: 'Sami Pharma' },
    { id: 4, name: 'Amlodipine 5mg', generic: 'Amlodipine', category: 'Cardiac', price: 95, cost: 65, stock: 120, shelf: 'D4', batch: 'BT2024004', expiry: '2026-01-10', manufacturer: 'Searle' },
    { id: 5, name: 'Metformin 500mg', generic: 'Metformin', category: 'Diabetes', price: 75, cost: 50, stock: 180, shelf: 'E5', batch: 'BT2024005', expiry: '2025-08-25', manufacturer: 'Getz Pharma' },
    { id: 6, name: 'Lisinopril 10mg', generic: 'Lisinopril', category: 'Cardiac', price: 130, cost: 90, stock: 95, shelf: 'D5', batch: 'BT2024006', expiry: '2025-11-30', manufacturer: 'Martin Dow' },
    { id: 7, name: 'Brufen 400mg', generic: 'Ibuprofen', category: 'Pain Relief', price: 110, cost: 75, stock: 250, shelf: 'A2', batch: 'BT2024007', expiry: '2025-07-15', manufacturer: 'Abbott' },
    { id: 8, name: 'Cetirizine 10mg', generic: 'Cetirizine', category: 'Allergy', price: 65, cost: 40, stock: 300, shelf: 'F1', batch: 'BT2024008', expiry: '2026-02-28', manufacturer: 'Pharmatec' },
    { id: 9, name: 'Amoxicillin 500mg', generic: 'Amoxicillin', category: 'Antibiotics', price: 280, cost: 200, stock: 150, shelf: 'B3', batch: 'BT2024009', expiry: '2025-05-20', manufacturer: 'GSK' },
    { id: 10, name: 'Pantoprazole 40mg', generic: 'Pantoprazole', category: 'Digestive', price: 150, cost: 100, stock: 180, shelf: 'C4', batch: 'BT2024010', expiry: '2025-10-10', manufacturer: 'Hilton Pharma' },
    { id: 11, name: 'Losartan 50mg', generic: 'Losartan', category: 'Cardiac', price: 145, cost: 100, stock: 110, shelf: 'D6', batch: 'BT2024011', expiry: '2026-03-15', manufacturer: 'Searle' },
    { id: 12, name: 'Montelukast 10mg', generic: 'Montelukast', category: 'Respiratory', price: 180, cost: 130, stock: 90, shelf: 'G1', batch: 'BT2024012', expiry: '2025-12-20', manufacturer: 'Sami Pharma' }
];

const ADMIN_CUSTOMERS = [
    { id: 1, name: 'Ahmed Khan', phone: '0300-1234567', email: 'ahmed@email.com', address: 'Lahore', type: 'regular', credit_limit: 10000, balance: 2500 },
    { id: 2, name: 'Fatima Ali', phone: '0321-9876543', email: 'fatima@email.com', address: 'Karachi', type: 'credit', credit_limit: 25000, balance: 5000 },
    { id: 3, name: 'Muhammad Usman', phone: '0333-5551234', email: 'usman@email.com', address: 'Islamabad', type: 'regular', credit_limit: 15000, balance: 0 },
    { id: 4, name: 'Ayesha Siddiqui', phone: '0345-7778899', email: 'ayesha@email.com', address: 'Rawalpindi', type: 'credit', credit_limit: 30000, balance: 8500 },
    { id: 5, name: 'Hassan Raza', phone: '0312-4445566', email: 'hassan@email.com', address: 'Faisalabad', type: 'regular', credit_limit: 5000, balance: 0 }
];

const ADMIN_ORDERS = [
    { id: 1001, customer: 'Ahmed Khan', date: '2024-01-15', total: 1250, status: 'completed', items: 3, payment: 'cash' },
    { id: 1002, customer: 'Fatima Ali', date: '2024-01-15', total: 3450, status: 'pending', items: 5, payment: 'credit' },
    { id: 1003, customer: 'Walk-in Customer', date: '2024-01-14', total: 850, status: 'completed', items: 2, payment: 'cash' },
    { id: 1004, customer: 'Muhammad Usman', date: '2024-01-14', total: 2100, status: 'completed', items: 4, payment: 'card' },
    { id: 1005, customer: 'Ayesha Siddiqui', date: '2024-01-13', total: 5670, status: 'pending', items: 8, payment: 'credit' }
];

const ADMIN_STATS = {
    totalSales: 125680,
    todaySales: 12450,
    totalOrders: 856,
    todayOrders: 23,
    totalCustomers: 245,
    lowStockItems: 8,
    pendingPayments: 45600,
    monthlyGrowth: 12.5
};

// ========== UTILITY FUNCTIONS ==========

function formatCurrency(amount) {
    return 'Rs. ' + parseFloat(amount).toLocaleString('en-PK', { minimumFractionDigits: 0 });
}

function showToast(message, type = 'success') {
    // Create toast container if not exists
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
    }

    const toastId = 'toast-' + Date.now();
    const bgClass = type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info';
    const icon = type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle';

    const toastHTML = `
        <div id="${toastId}" class="toast align-items-center text-white ${bgClass} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas fa-${icon} me-2"></i>${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;

    container.insertAdjacentHTML('beforeend', toastHTML);
    const toast = new bootstrap.Toast(document.getElementById(toastId), { delay: 3000 });
    toast.show();

    // Remove after hide
    document.getElementById(toastId).addEventListener('hidden.bs.toast', function() {
        this.remove();
    });
}

// ========== MOCK API FUNCTIONS ==========

function searchMedicines(term) {
    const searchTerm = term.toLowerCase();
    return ADMIN_MEDICINES.filter(med =>
        med.name.toLowerCase().includes(searchTerm) ||
        med.generic.toLowerCase().includes(searchTerm) ||
        med.category.toLowerCase().includes(searchTerm)
    );
}

function searchCustomers(term) {
    const searchTerm = term.toLowerCase();
    return ADMIN_CUSTOMERS.filter(cust =>
        cust.name.toLowerCase().includes(searchTerm) ||
        cust.phone.includes(searchTerm)
    );
}

function getMedicineById(id) {
    return ADMIN_MEDICINES.find(med => med.id === id);
}

function getCustomerById(id) {
    return ADMIN_CUSTOMERS.find(cust => cust.id === id);
}

function getStats() {
    return ADMIN_STATS;
}

function getRecentOrders(limit = 5) {
    return ADMIN_ORDERS.slice(0, limit);
}

function getLowStockMedicines(threshold = 100) {
    return ADMIN_MEDICINES.filter(med => med.stock < threshold);
}

// ========== AUTH FUNCTIONS ==========

function checkAdminAuth() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
        // For demo, auto-login as admin
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('user', JSON.stringify({ username: 'Admin', role: 'admin' }));
    }
    return true;
}

function adminLogout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.clear();
        window.location.href = '../login.html';
    }
}

// ========== BILLING FUNCTIONS ==========

let billingCart = [];
let invoiceNumber = 'INV-' + Date.now().toString().slice(-8);

function addToBillingCart(medicine, quantity = 1) {
    const existing = billingCart.find(item => item.id === medicine.id);
    if (existing) {
        existing.quantity += quantity;
    } else {
        billingCart.push({ ...medicine, quantity });
    }
    updateBillingUI();
    showToast(`Added ${medicine.name} to cart`, 'success');
}

function removeFromBillingCart(medicineId) {
    billingCart = billingCart.filter(item => item.id !== medicineId);
    updateBillingUI();
    showToast('Item removed from cart', 'info');
}

function updateBillingQuantity(medicineId, quantity) {
    const item = billingCart.find(i => i.id === medicineId);
    if (item) {
        item.quantity = Math.max(1, quantity);
        updateBillingUI();
    }
}

function getBillingTotal() {
    return billingCart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
}

function clearBillingCart() {
    billingCart = [];
    updateBillingUI();
}

function updateBillingUI() {
    // This will be called to refresh the billing display
    const event = new CustomEvent('billingCartUpdated', { detail: { cart: billingCart, total: getBillingTotal() } });
    document.dispatchEvent(event);
}

function processBilling(customerInfo, paymentMethod) {
    const order = {
        id: Date.now(),
        invoiceNumber: invoiceNumber,
        customer: customerInfo,
        items: [...billingCart],
        total: getBillingTotal(),
        paymentMethod: paymentMethod,
        date: new Date().toISOString()
    };

    // Save to localStorage for demo
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    orders.push(order);
    localStorage.setItem('orders', JSON.stringify(orders));

    // Clear cart and generate new invoice number
    clearBillingCart();
    invoiceNumber = 'INV-' + Date.now().toString().slice(-8);

    showToast('Order processed successfully!', 'success');
    return order;
}

// ========== INITIALIZE ==========

document.addEventListener('DOMContentLoaded', function() {
    checkAdminAuth();

    // Load app.js if needed for shared functions
    if (typeof AppState === 'undefined') {
        console.log('Admin App initialized with mock data');
    }
});

// Export for use in other scripts
window.AdminApp = {
    medicines: ADMIN_MEDICINES,
    customers: ADMIN_CUSTOMERS,
    orders: ADMIN_ORDERS,
    stats: ADMIN_STATS,
    searchMedicines,
    searchCustomers,
    getMedicineById,
    getCustomerById,
    getStats,
    getRecentOrders,
    getLowStockMedicines,
    addToBillingCart,
    removeFromBillingCart,
    updateBillingQuantity,
    getBillingTotal,
    clearBillingCart,
    processBilling,
    formatCurrency,
    showToast,
    adminLogout
};
