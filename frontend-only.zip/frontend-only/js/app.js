/**
 * Frontend-Only Pharmacy App
 * Works without backend - Uses dummy data and localStorage
 */

// ============================================
// Dummy Data
// ============================================
const DUMMY_MEDICINES = [
    {
        id: 1,
        name: "Paracetamol 500mg",
        category: "Pain Relief",
        price: 5.99,
        stock: 150,
        description: "Effective pain relief and fever reducer. Safe for adults and children over 12.",
        manufacturer: "PharmaCare Ltd",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    },
    {
        id: 2,
        name: "Amoxicillin 250mg",
        category: "Antibiotics",
        price: 12.50,
        stock: 80,
        description: "Broad-spectrum antibiotic for bacterial infections. Requires prescription.",
        manufacturer: "MediPharm Inc",
        image: "images/default-medicine.jpg",
        requires_prescription: true
    },
    {
        id: 3,
        name: "Vitamin C 1000mg",
        category: "Vitamins",
        price: 8.99,
        stock: 200,
        description: "High-strength vitamin C supplement for immune support.",
        manufacturer: "VitaHealth",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    },
    {
        id: 4,
        name: "Ibuprofen 400mg",
        category: "Pain Relief",
        price: 7.50,
        stock: 120,
        description: "Anti-inflammatory pain reliever for headaches, muscle pain, and fever.",
        manufacturer: "PharmaCare Ltd",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    },
    {
        id: 5,
        name: "Omeprazole 20mg",
        category: "Digestive",
        price: 15.99,
        stock: 90,
        description: "Proton pump inhibitor for acid reflux and heartburn relief.",
        manufacturer: "GastroMed",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    },
    {
        id: 6,
        name: "Cetirizine 10mg",
        category: "Allergy",
        price: 6.99,
        stock: 175,
        description: "Non-drowsy antihistamine for allergy relief.",
        manufacturer: "AllerCare",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    },
    {
        id: 7,
        name: "Metformin 500mg",
        category: "Diabetes",
        price: 9.99,
        stock: 100,
        description: "Oral diabetes medicine for blood sugar control. Requires prescription.",
        manufacturer: "DiabetaCare",
        image: "images/default-medicine.jpg",
        requires_prescription: true
    },
    {
        id: 8,
        name: "Multivitamin Complex",
        category: "Vitamins",
        price: 14.99,
        stock: 250,
        description: "Complete daily multivitamin with essential minerals.",
        manufacturer: "VitaHealth",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    },
    {
        id: 9,
        name: "Aspirin 100mg",
        category: "Pain Relief",
        price: 4.50,
        stock: 180,
        description: "Low-dose aspirin for heart health and mild pain relief.",
        manufacturer: "HeartCare Pharma",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    },
    {
        id: 10,
        name: "Losartan 50mg",
        category: "Blood Pressure",
        price: 18.99,
        stock: 60,
        description: "ACE inhibitor for blood pressure control. Requires prescription.",
        manufacturer: "CardioMed",
        image: "images/default-medicine.jpg",
        requires_prescription: true
    },
    {
        id: 11,
        name: "Calcium + Vitamin D",
        category: "Vitamins",
        price: 11.99,
        stock: 140,
        description: "Bone health supplement with calcium and vitamin D3.",
        manufacturer: "BoneHealth Plus",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    },
    {
        id: 12,
        name: "Fluconazole 150mg",
        category: "Antifungal",
        price: 8.50,
        stock: 70,
        description: "Antifungal medication for yeast infections.",
        manufacturer: "FungiCare",
        image: "images/default-medicine.jpg",
        requires_prescription: false
    }
];

const DUMMY_CATEGORIES = [
    { id: 1, name: "Pain Relief", icon: "fa-pills", color: "#ef4444" },
    { id: 2, name: "Antibiotics", icon: "fa-capsules", color: "#f59e0b" },
    { id: 3, name: "Vitamins", icon: "fa-leaf", color: "#10b981" },
    { id: 4, name: "Digestive", icon: "fa-stomach", color: "#8b5cf6" },
    { id: 5, name: "Allergy", icon: "fa-lungs", color: "#ec4899" },
    { id: 6, name: "Diabetes", icon: "fa-syringe", color: "#0ea5e9" },
    { id: 7, name: "Blood Pressure", icon: "fa-heart-pulse", color: "#dc2626" },
    { id: 8, name: "Antifungal", icon: "fa-shield-virus", color: "#14b8a6" }
];

const DUMMY_USER = {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    phone: "555-123-4567",
    address: "123 Main Street, City, State 12345"
};

// ============================================
// App State
// ============================================
const AppState = {
    isLoggedIn: false,
    user: null,
    cart: [],

    init() {
        // Load from localStorage
        this.isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
        this.user = JSON.parse(localStorage.getItem('user')) || null;
        this.cart = JSON.parse(localStorage.getItem('cart')) || [];
        this.updateUI();
    },

    save() {
        localStorage.setItem('isLoggedIn', this.isLoggedIn);
        localStorage.setItem('user', JSON.stringify(this.user));
        localStorage.setItem('cart', JSON.stringify(this.cart));
    },

    updateUI() {
        this.updateCartBadge();
        this.updateAuthButtons();
    },

    updateCartBadge() {
        const badge = document.getElementById('cart-count');
        if (badge) {
            const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
            badge.textContent = totalItems;
            badge.style.display = totalItems > 0 ? 'inline-block' : 'none';
        }
    },

    updateAuthButtons() {
        const loginBtn = document.getElementById('login-btn');
        const userDropdown = document.getElementById('user-dropdown');
        const userName = document.getElementById('user-name');

        if (this.isLoggedIn && this.user) {
            if (loginBtn) loginBtn.style.display = 'none';
            if (userDropdown) {
                userDropdown.style.display = 'block';
                if (userName) userName.textContent = this.user.name;
            }
        } else {
            if (loginBtn) loginBtn.style.display = 'block';
            if (userDropdown) userDropdown.style.display = 'none';
        }
    }
};

// ============================================
// Authentication Functions
// ============================================
function login(email = '', password = '') {
    // Simulate login - accept any credentials and log in as admin
    AppState.isLoggedIn = true;
    AppState.user = {
        ...DUMMY_USER,
        email: email || DUMMY_USER.email,
        role: 'admin' // Set as admin for demo
    };
    AppState.save();

    showToast('Login Successful!', 'Welcome back, Admin!', 'success');

    // Redirect to admin portal
    setTimeout(() => {
        window.location.href = 'admin/modern-billing.html';
    }, 1000);
}

function register(name = '', email = '', password = '') {
    // Simulate registration
    AppState.isLoggedIn = true;
    AppState.user = {
        ...DUMMY_USER,
        name: name || 'New User',
        email: email || 'user@example.com'
    };
    AppState.save();

    showToast('Registration Successful!', 'Welcome to MedCare Pharmacy!', 'success');

    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1000);
}

function logout() {
    AppState.isLoggedIn = false;
    AppState.user = null;
    AppState.save();
    AppState.updateUI();

    showToast('Logged Out', 'See you next time!', 'info');

    setTimeout(() => {
        window.location.href = 'index.html';
    }, 500);
}

// ============================================
// Cart Functions
// ============================================
function addToCart(medicineId, quantity = 1) {
    const medicine = DUMMY_MEDICINES.find(m => m.id === parseInt(medicineId));
    if (!medicine) {
        showToast('Error', 'Medicine not found', 'error');
        return;
    }

    const existingItem = AppState.cart.find(item => item.id === medicine.id);

    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        AppState.cart.push({
            id: medicine.id,
            name: medicine.name,
            price: medicine.price,
            quantity: quantity,
            image: medicine.image
        });
    }

    AppState.save();
    AppState.updateCartBadge();

    showToast('Added to Cart', `${medicine.name} x${quantity}`, 'success');

    // Animate cart icon
    const cartIcon = document.querySelector('.btn-cart');
    if (cartIcon) {
        cartIcon.classList.add('animate__animated', 'animate__rubberBand');
        setTimeout(() => {
            cartIcon.classList.remove('animate__animated', 'animate__rubberBand');
        }, 1000);
    }
}

function removeFromCart(medicineId) {
    const index = AppState.cart.findIndex(item => item.id === parseInt(medicineId));
    if (index > -1) {
        const item = AppState.cart[index];
        AppState.cart.splice(index, 1);
        AppState.save();
        AppState.updateCartBadge();
        showToast('Removed from Cart', item.name, 'info');

        // Re-render cart if on cart page
        if (typeof renderCart === 'function') {
            renderCart();
        }
    }
}

function updateCartQuantity(medicineId, quantity) {
    const item = AppState.cart.find(item => item.id === parseInt(medicineId));
    if (item) {
        item.quantity = Math.max(1, parseInt(quantity) || 1);
        AppState.save();
        AppState.updateCartBadge();

        if (typeof renderCart === 'function') {
            renderCart();
        }
    }
}

function getCartTotal() {
    return AppState.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

function clearCart() {
    AppState.cart = [];
    AppState.save();
    AppState.updateCartBadge();
    showToast('Cart Cleared', 'All items removed', 'info');

    if (typeof renderCart === 'function') {
        renderCart();
    }
}

// ============================================
// Medicine Functions
// ============================================
function getMedicines(category = null, searchTerm = null) {
    let medicines = [...DUMMY_MEDICINES];

    if (category && category !== 'all') {
        medicines = medicines.filter(m => m.category.toLowerCase() === category.toLowerCase());
    }

    if (searchTerm) {
        const term = searchTerm.toLowerCase();
        medicines = medicines.filter(m =>
            m.name.toLowerCase().includes(term) ||
            m.category.toLowerCase().includes(term) ||
            m.description.toLowerCase().includes(term)
        );
    }

    return medicines;
}

function getMedicineById(id) {
    return DUMMY_MEDICINES.find(m => m.id === parseInt(id));
}

function getCategories() {
    return DUMMY_CATEGORIES;
}

function searchMedicines(query) {
    if (!query || query.length < 2) return [];

    const term = query.toLowerCase();
    return DUMMY_MEDICINES.filter(m =>
        m.name.toLowerCase().includes(term) ||
        m.category.toLowerCase().includes(term)
    ).slice(0, 8);
}

// ============================================
// UI Helper Functions
// ============================================
function showToast(title, message, type = 'info') {
    // Create toast container if not exists
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        container.style.zIndex = '9999';
        container.style.marginTop = '80px';
        document.body.appendChild(container);
    }

    const bgClass = {
        'success': 'bg-success',
        'error': 'bg-danger',
        'warning': 'bg-warning',
        'info': 'bg-info'
    }[type] || 'bg-info';

    const iconClass = {
        'success': 'fa-check-circle',
        'error': 'fa-times-circle',
        'warning': 'fa-exclamation-triangle',
        'info': 'fa-info-circle'
    }[type] || 'fa-info-circle';

    const toast = document.createElement('div');
    toast.className = `toast show align-items-center text-white ${bgClass} border-0`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas ${iconClass} me-2"></i>
                <strong>${title}</strong><br>
                <small>${message}</small>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" onclick="this.parentElement.parentElement.remove()"></button>
        </div>
    `;

    container.appendChild(toast);

    // Auto-remove after 4 seconds
    setTimeout(() => {
        toast.classList.add('animate__animated', 'animate__fadeOutRight');
        setTimeout(() => toast.remove(), 500);
    }, 4000);
}

function formatCurrency(amount) {
    return '$' + parseFloat(amount).toFixed(2);
}

function renderMedicineCard(medicine) {
    return `
        <div class="col-md-6 col-lg-4 col-xl-3 mb-4">
            <div class="card medicine-card h-100 border-0 shadow-custom">
                <div class="position-relative overflow-hidden">
                    <img src="${medicine.image}" class="card-img-top" alt="${medicine.name}"
                         style="height: 200px; object-fit: cover;"
                         onerror="this.src='https://via.placeholder.com/300x200?text=Medicine'">
                    ${medicine.requires_prescription ?
                        '<span class="badge bg-warning position-absolute top-0 end-0 m-2"><i class="fas fa-file-prescription me-1"></i>Rx Required</span>'
                        : ''}
                    <span class="badge bg-primary position-absolute top-0 start-0 m-2">${medicine.category}</span>
                </div>
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title fw-bold">${medicine.name}</h5>
                    <p class="card-text text-muted small flex-grow-1">${medicine.description.substring(0, 80)}...</p>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="h5 text-primary mb-0">${formatCurrency(medicine.price)}</span>
                        <small class="text-${medicine.stock > 50 ? 'success' : 'warning'}">
                            <i class="fas fa-box me-1"></i>${medicine.stock} in stock
                        </small>
                    </div>
                    <div class="d-flex gap-2 align-items-center">
                        <div class="input-group input-group-sm" style="max-width: 100px;">
                            <button class="btn btn-outline-secondary" type="button" onclick="decrementQty(${medicine.id})">-</button>
                            <input type="number" class="form-control text-center" id="qty-${medicine.id}" value="1" min="1" max="${medicine.stock}">
                            <button class="btn btn-outline-secondary" type="button" onclick="incrementQty(${medicine.id})">+</button>
                        </div>
                        <button class="btn btn-primary flex-grow-1" onclick="addToCartFromCard(${medicine.id})">
                            <i class="fas fa-cart-plus me-1"></i> Add
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function incrementQty(medicineId) {
    const input = document.getElementById(`qty-${medicineId}`);
    if (input) {
        const max = parseInt(input.getAttribute('max')) || 99;
        const current = parseInt(input.value) || 1;
        if (current < max) input.value = current + 1;
    }
}

function decrementQty(medicineId) {
    const input = document.getElementById(`qty-${medicineId}`);
    if (input) {
        const current = parseInt(input.value) || 1;
        if (current > 1) input.value = current - 1;
    }
}

function addToCartFromCard(medicineId) {
    const input = document.getElementById(`qty-${medicineId}`);
    const quantity = input ? parseInt(input.value) || 1 : 1;
    addToCart(medicineId, quantity);
}

// ============================================
// Checkout Functions
// ============================================
function checkout() {
    if (AppState.cart.length === 0) {
        showToast('Cart Empty', 'Please add items to your cart first', 'warning');
        return;
    }

    if (!AppState.isLoggedIn) {
        showToast('Login Required', 'Please login to checkout', 'warning');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1500);
        return;
    }

    // Simulate order placement
    const orderId = 'ORD-' + Date.now();
    const total = getCartTotal();

    showToast('Order Placed!', `Order ${orderId} - Total: ${formatCurrency(total)}`, 'success');

    // Clear cart
    AppState.cart = [];
    AppState.save();
    AppState.updateCartBadge();

    // Show success modal or redirect
    setTimeout(() => {
        alert(`Thank you for your order!\n\nOrder ID: ${orderId}\nTotal: ${formatCurrency(total)}\n\nYour order will be delivered within 2-3 business days.`);
        window.location.href = 'index.html';
    }, 1000);
}

// ============================================
// Search Functionality
// ============================================
function initSearch() {
    const searchInput = document.getElementById('search-input');
    const suggestionsDropdown = document.getElementById('search-suggestions');

    if (!searchInput) return;

    let debounceTimer;

    searchInput.addEventListener('input', function() {
        clearTimeout(debounceTimer);
        const query = this.value.trim();

        if (query.length < 2) {
            if (suggestionsDropdown) suggestionsDropdown.style.display = 'none';
            return;
        }

        debounceTimer = setTimeout(() => {
            const results = searchMedicines(query);

            if (results.length > 0 && suggestionsDropdown) {
                suggestionsDropdown.innerHTML = results.map(m => `
                    <div class="suggestion-item" onclick="selectMedicine(${m.id})">
                        <div class="d-flex align-items-center">
                            <img src="${m.image}" alt="${m.name}" class="me-3"
                                 style="width: 50px; height: 50px; object-fit: cover; border-radius: 8px;"
                                 onerror="this.src='https://via.placeholder.com/50?text=Med'">
                            <div>
                                <div class="fw-bold">${m.name}</div>
                                <small class="text-muted">${m.category} - ${formatCurrency(m.price)}</small>
                            </div>
                        </div>
                    </div>
                `).join('');
                suggestionsDropdown.style.display = 'block';
            } else if (suggestionsDropdown) {
                suggestionsDropdown.style.display = 'none';
            }
        }, 300);
    });

    // Hide suggestions when clicking outside
    document.addEventListener('click', function(e) {
        if (suggestionsDropdown && !searchInput.contains(e.target) && !suggestionsDropdown.contains(e.target)) {
            suggestionsDropdown.style.display = 'none';
        }
    });
}

function selectMedicine(id) {
    window.location.href = `medicine-detail.html?id=${id}`;
}

function performSearch() {
    const searchInput = document.getElementById('search-input');
    if (searchInput && searchInput.value.trim()) {
        window.location.href = `search.html?q=${encodeURIComponent(searchInput.value.trim())}`;
    }
}

// ============================================
// Navbar Scroll Effect
// ============================================
function initNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;

    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
}

// ============================================
// Initialize App
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    AppState.init();
    initSearch();
    initNavbarScroll();

    console.log('🏥 MedCare Pharmacy Frontend Loaded');
    console.log('📦 Cart Items:', AppState.cart.length);
    console.log('👤 Logged In:', AppState.isLoggedIn);
});

// Export for use in other scripts
window.AppState = AppState;
window.DUMMY_MEDICINES = DUMMY_MEDICINES;
window.DUMMY_CATEGORIES = DUMMY_CATEGORIES;
window.login = login;
window.register = register;
window.logout = logout;
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateCartQuantity = updateCartQuantity;
window.getCartTotal = getCartTotal;
window.clearCart = clearCart;
window.getMedicines = getMedicines;
window.getMedicineById = getMedicineById;
window.getCategories = getCategories;
window.showToast = showToast;
window.formatCurrency = formatCurrency;
window.renderMedicineCard = renderMedicineCard;
window.checkout = checkout;
window.performSearch = performSearch;
